#include "ModelAsset.h"

int EngineTools::ModelAsset::modelCount = 0;