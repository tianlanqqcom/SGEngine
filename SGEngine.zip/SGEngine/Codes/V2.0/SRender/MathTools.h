#ifndef SRENDER_MATHTOOLS
#define SRENDER_MATHTOOLS

#include "MathTools/MathException.h"
#include "MathTools/Matrix.h"

#endif // SRENDER_MATHTOOLS

